Simplex Algorithm.
Can solve LP(Linear Programing) and ILP(Ingterger Linear Programing)

Developed by Jiachi Zou.
