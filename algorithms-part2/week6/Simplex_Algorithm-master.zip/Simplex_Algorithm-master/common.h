#ifndef __COMMON__
#define __COMMON__

#include <stdio.h>
#include <stdlib.h>

#define u8		unsigned char
#define i8		char
#define u16		unsigned short int
#define i16		short int
#define u32		unsigned int
#define i32		int

#endif