package test;
import gui.*;
public class GuiTest {
	public static void main(String[] args){
		try {
			Window wnd;
			wnd = new Window();
			wnd.setSize(800,600);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
