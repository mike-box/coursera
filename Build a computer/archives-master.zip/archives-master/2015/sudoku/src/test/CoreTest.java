package test;

import java.io.FileNotFoundException;
import java.io.IOException;

import core.Game;

public class CoreTest {
	public static void main(String[] args) throws FileNotFoundException, IOException{
		Game.init();
	}
}
