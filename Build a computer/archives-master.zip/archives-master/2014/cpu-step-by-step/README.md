# 简单CPU设计

一个简单的8位CPU设计，[详细介绍 https://lianera.github.io/post/2014/cpu-step-by-step/](https://lianera.github.io/post/2014/cpu-step-by-step/)。

用logisim打开本目录的finish.circ，按Ctrl+T单步运行
