package test;
import javax.swing.JFrame;

import gui.*;
public class GuiTest {
	public static void main(String[] args){
		Window wnd;
		try {
			wnd = new Window();
			//wnd.setSize(640,480);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
