package core;

/**这是一个方向的枚举，包括上下左右
 * @author duan
 * @version 2.0
 */
public enum Direction {
	LEFT,UP,RIGHT,DOWN
}
