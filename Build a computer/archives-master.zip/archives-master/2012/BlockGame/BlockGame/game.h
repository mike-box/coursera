#pragma once
void InitGame();
void RunGame();
void ReleaseGame();
