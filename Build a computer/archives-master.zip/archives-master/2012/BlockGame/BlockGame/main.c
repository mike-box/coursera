#include <stdio.h>
#include "game.h"

int main()
{
	InitGame();
	RunGame();
	ReleaseGame();
	return 0;
}