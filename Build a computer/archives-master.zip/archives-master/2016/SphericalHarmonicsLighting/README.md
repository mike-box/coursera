# 球谐光照

已经移到单独的仓库：[https://github.com/lianera/SphericalHarmonicsLighting](https://github.com/lianera/SphericalHarmonicsLighting)