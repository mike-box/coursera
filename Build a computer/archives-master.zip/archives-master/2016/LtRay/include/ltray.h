#pragma once
#ifndef LTRAY_H
#define LTRAY_H

#include "utils.h"

#include "geometry.h"
#include "surface.h"
#include "world.h"
#include "shader.h"
#include "tracing.h"

#endif