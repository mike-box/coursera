#include <numeric>
#include "minimization.hpp"
