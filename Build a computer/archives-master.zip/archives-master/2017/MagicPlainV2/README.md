# Magic Plain v2

[详细介绍](https://lianera.github.io/2017/magicplainv2/)