// Robot.h: interface for the CRobot class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ROBOT_H__0FC5438C_2360_4C72_94C5_AF8846BA263B__INCLUDED_)
#define AFX_ROBOT_H__0FC5438C_2360_4C72_94C5_AF8846BA263B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CRobot  
{
public:
	CRobot();
	virtual ~CRobot();

};

#endif // !defined(AFX_ROBOT_H__0FC5438C_2360_4C72_94C5_AF8846BA263B__INCLUDED_)
