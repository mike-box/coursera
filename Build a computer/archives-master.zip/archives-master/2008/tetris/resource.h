//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ����˹����.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MY_DIALOG                   102
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       130
#define IDD_NAME                        134
#define IDC_NAME                        1014
#define IDM_RESTART                     32771
#define IDM_LOAD                        32772
#define IDM_SAVE                        32773
#define IDM_CLOSE                       32774
#define IDM_PAUSE                       32775
#define IDM_RANGE                       32776
#define IDM_ABOUT                       32779
#define IDM_SOUND                       32780

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32781
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
