//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ̰����.rc
//
#define IDC_MYICON                      2
#define IDD_MY_DIALOG                   102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_MY                          107
#define IDI_SMALL                       108
#define IDC_MY                          109
#define IDR_MAINFRAME                   128
#define IDB_HEAD                        129
#define IDB_NODE                        130
#define IDB_SHRUNKEN                    131
#define IDB_APPLE                       132
#define IDR_EAT                         133
#define IDR_BACK                        134
#define IDR_LOSE                        135
#define IDR_PASSLEVEL                   136
#define IDB_LOGO                        137
#define IDB_THEEND                      138
#define IDD_NAME                        139
#define IDR_THEEND                      140
#define IDC_EDIT                        1000
#define IDM_LOAD                        32771
#define IDM_SAVE                        32772
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
