//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ��������.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_DIALOGBAR                   103
#define IDR_MAINFRAME                   128
#define IDR_MYTYPE                      129
#define IDD_CHILD                       130
#define IDR_CTRL                        131
#define IDI_STOP                        134
#define IDI_PAUSE                       135
#define IDR_MENU_ACTIONLIST             136
#define IDI_SHOWICON                    137
#define IDC_LIST_ACTION                 1000
#define IDC_BUTTON_ADD                  1001
#define IDC_BUTTON_DELETE               1002
#define IDC_BUTTON_CLEAN                1003
#define IDC_COMBO_KEY                   1004
#define IDC_EDIT_DEFER                  1007
#define IDC_EDITREPEAT                  1008
#define IDC_EDIT_POSX                   1009
#define IDC_EDIT_POSY                   1010
#define IDC_CHECK_KEYDOWN               1011
#define IDC_CHECK_KEYUP                 1012
#define IDC_CHECK_MOVEMOUSE             1013
#define IDC_CHECK_GETPOS                1016
#define IDC_CHECK_ALWAYREC              1019
#define ID_CTRL_PAUSE                   32774
#define ID_CTRL_STOP                    32775
#define ID_CTRL_REC                     32776
#define ID_CTRL_RUN                     32777

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32779
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
