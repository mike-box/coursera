#if !defined(AFX_TBCTRL_H__7411627E_04B8_40C1_B74A_815B2CDEECDC__INCLUDED_)
#define AFX_TBCTRL_H__7411627E_04B8_40C1_B74A_815B2CDEECDC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TBCtrl.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTBCtrl window

class CTBCtrl : public CToolBarCtrl
{
// Construction
public:
	CTBCtrl();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTBCtrl)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CTBCtrl();

	// Generated message map functions
protected:
	//{{AFX_MSG(CTBCtrl)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TBCTRL_H__7411627E_04B8_40C1_B74A_815B2CDEECDC__INCLUDED_)
