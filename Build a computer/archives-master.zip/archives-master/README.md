# Lianera程序合集

过去几年写过的一些程序，每个程序文件夹里面都有简要的README.md介绍，详细介绍请参考[我的个人小站](https://lianera.github.io/)。

可执行程序可以在[Release](https://github.com/lianera/archives/releases)中下载。

+ 2017
	* [MagicPlainV2](2017/MagicPlainV2)
	* [GradientDescent](2017/GradientDescent)
+ 2016
	* [LtRay光线跟踪器](2016/LtRay)
	* [球谐光照](2016/SphericalHarmonicsLighting)
+ 2015
	* [Sudoku](2015/sudoku)
+ 2014
	* [简单CPU设计实践](2014/cpu-step-by-step)
	* [Game2048](2014/game2048)
+ 2013
	* [MagicPlain](2013/MagicPlain)
	* [贪吃蛇（二）](2013/snake2)
+ 2012
	* [贴吧用户ID挖掘机](2012/TiebaDigger)
	* [Panzer War](2012/PanzerWar)
	* [Block Game](2012/BlockGame)
+ 2008
	* [贪吃蛇（一）](2008/snake1)
	* [俄罗斯方块](2008/tetris)
	* [按键助手](2008/keyhelper)