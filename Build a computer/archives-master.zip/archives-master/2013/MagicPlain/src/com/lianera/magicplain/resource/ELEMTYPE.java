package com.lianera.magicplain.resource;

public enum ELEMTYPE {
	BLANK, 
	DECORATE,
	PROP,
	BLOCK, 
	BOMB,
	CHARACTER, 
	EXPLOSION,
	EFFECT
};