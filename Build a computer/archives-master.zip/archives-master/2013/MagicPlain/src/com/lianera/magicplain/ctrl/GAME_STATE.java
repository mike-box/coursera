package com.lianera.magicplain.ctrl;

public enum GAME_STATE{
	SHOWLOGO,
	SHOWMENU,
	INIT,
	DESTROY,
	VICTORY,
	FAIL,
	RUN,
	OVER,
	EXIT,
	SHOWSCENE
}
