#include "manager.h"

int main()
{
	Game game(800, 600);
	game.Loop();
	return 0;
}